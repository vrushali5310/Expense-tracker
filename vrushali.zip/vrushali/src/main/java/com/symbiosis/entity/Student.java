package com.symbiosis.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Expenses")
public class Student
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	private String expense;
	private String expensetype;
	private String date;
	private String expensecost;
	
	
	public Student() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getExpense() {
		return expense;
	}
	public void setExpense(String expense) {
		this.expense = expense;
	}
	public String getExpensetype() {
		return expensetype;
	}
	public void setExpensetype(String expensetype) {
		this.expensetype = expensetype;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getExpensecost() {
		return expensecost;
	}
	public void setExpensecost(String expensecost) {
		this.expensecost = expensecost;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", expense=" + expense + ", expensetype=" + expensetype
				+ ", date=" + date + ", expensecost=" + expensecost + "]";
	}
	
}